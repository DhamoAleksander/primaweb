using System;
using System.ComponentModel.DataAnnotations;

namespace dhamo.aleksander._5h.PrimaWeb.Models
{
    public class Prenotazione
    {
        public int PrenotazioneId { get; set; }
        public string Nome { get; set; }

        [Required(ErrorMessage="Inserisci una email")]
        [EmailAddress]
        public string Email { get; set; }
    }
}