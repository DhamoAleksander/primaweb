﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using dhamo.aleksander._5h.PrimaWeb.Models;

namespace dhamo.aleksander._5h.PrimaWeb.Controllers
{
    public class HomeController : Controller
    {
        //static List<Prenotazione> Prenotazioni = new List<Prenotazione>();
        /*private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }*/

        public IActionResult Index()
        {
            /*//instanzio un Context
            var db = new PrenotazioneContext();

            //Aggiungo un record alla tabella Prenotazioni
            db.Prenotazioni.Add(new Prenotazione { Nome = "Aleksander", Email="Aleksander@gmail.com" });
            db.SaveChanges();*/
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }
         
        [HttpGet]
        public IActionResult Prenota()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Prenota(Prenotazione p)
        {
            //tipo - etichetta - operatore - valore - terminatore di istruzione
            var db=new PrenotazioneContext(); //oppure PrenotazioneContext db=new PrenotazioneContext(); 
            db.Prenotazioni.Add(p);
            db.SaveChanges();
            return View("Grazie", db);
        }

        [HttpPost]
        public IActionResult Grazie()
        {
            return View();
        }

        //cancella prenotazione
        public IActionResult Cancella(int id)
        {
            var db=new PrenotazioneContext();
            Prenotazione prenotazione = db.Prenotazioni.Find(id);
            db.Remove(prenotazione);
            db.SaveChanges();
            return View("Cancella",db);
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
