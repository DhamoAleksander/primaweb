DELETE FROM Prenotazioni;

SELECT * FROM Prenotazioni;