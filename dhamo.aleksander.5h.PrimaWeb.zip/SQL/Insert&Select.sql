-- SQLite
INSERT INTO Prenotazioni (Nome, Email)
VALUES ("Pino","Pino@gino.com");

SELECT PrenotazioneId, Nome, Email
FROM Prenotazioni;